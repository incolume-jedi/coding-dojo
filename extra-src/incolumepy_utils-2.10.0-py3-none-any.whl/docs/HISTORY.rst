HISTORY
========

This package came from personal needs and has evolved in a way that was surprising.
Faced with this incredible evolution I decided to share it via pypi.org.


Este pacote surgiu de necessidades pessoais e evoluiu de maneira a surpriendente.
Diante desta incrivel evolução resolvi compartilha-lo via pypi.org.
